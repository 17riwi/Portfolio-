// New clean script

  //
  const et = document.getElementById("exercise-table");

  // Färger
  const col = [
    '#ffffff',
    '#ffff77',
    '#ffea6d',
    '#ffd463',
    '#ffbf59',
    '#ffaa4f',
    '#ff9545',
    '#ff803b',
    '#ff6a32',
    '#ff5528',
    '#ff401e',
    '#ff2b14',
    '#ff150a',
    '#ea0000',
    '#d40000',
    '#bf0000',
    '#aa0000',
    '#950000',
    '#6a0000',
    '#550000',
    '#400000',
    '#2b0000',
    '#150000',
    '#000000'
  ]
  
  // Kroppsdelar : Existerar för att underlätta kod
  const p = [
    "f1","f2","f3","f4","f5",
    "f6","f7","f8","f9","f10","f11",
    "f12","f13","f14","f15",
    "f16","f17","f18","f19",
    "f20","f21","f22","f23",
    "b1","b2","b3","b4","b5",
    "b6","b7","b8","b9","b10",
    "b11","b12","b13","b14",
    "b15","b16","b17","b18",
    "b19","b20","b21","b22"
  ]
  
  // Skapar en lika lång lista som kroppsdelar med siffror som placeholders. (Rank-listan)
  const pr = new Array(p.length).fill(0);
  
  // Kategorierna
  const category = [
    
    // Bröst
    {
      title    : 'Bröst',
      parentID : 'accordion'
    },
    
    // Mage
    {
      title    : 'Mage',
      parentID : 'accordion'
    },
        // Magmuskler (Raka)
        {
          title    : 'Magmuskler (Raka)',
          ID       : 'magmuskler-raka',
          parentID : 'list-mage'
        },
        // Magmuskler (Sida)
        {
          title    : 'Magmuskler (Sida)',
          ID       : 'magmuskler-sida',
          parentID : 'list-mage'
        },
    
    // Rygg
    {
      title    : 'Rygg',
      parentID : 'accordion'
    },
        // Övre Rygg
        {
          title    : 'Övre Rygg',
          ID       : 'övre-rygg',
          parentID : 'list-rygg'
        },
        // Nedre Rygg
        {
          title    : 'Nedre Rygg',
          ID       : 'nedre-rygg',
          parentID : 'list-rygg'
        },
    
    // Armar
    {
      title    : 'Armar',
      parentID : 'accordion'
    },
        // Axlar
        {
          title    : 'Axlar',
          parentID : 'list-armar'
        },
        // Biceps
        {
          title    : 'Biceps',
          parentID : 'list-armar'
        },
        // Triceps
        {
          title    : 'Triceps',
          parentID : 'list-armar'
        },
    
    // Ben
    {
      title    : 'Ben',
      parentID : 'accordion'
    },
        // Höftböjarmuskel
        {
          title    : 'Höftböjarmuskel',
          parentID : 'list-ben'
        },
        // Rumpa
        {
          title    : 'Rumpa',
          parentID : 'list-ben'
        },
        // Lår
        {
          title    : 'Lår',
          parentID : 'list-ben'
        },
        // Vader
        {
          title    : 'Vader',
          parentID : 'list-ben'
        }
  ];

  // Övningar
  const exercises = [
    // Dips
    {"name":"Dips","group":["triceps","axlar","bröst"],"muscles":["b5","b4","f4","f8"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/43","rep":"10","ID":"Dips","rank":[3,3,3,2],"index":0},
    // Armhävningar
    {"name":"Armhävningar","group":["triceps","axlar","bröst"],"muscles":["b5","b4","f4","f8"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/533","rep":"10","ID":"Armhävningar","rank":[3,1,1,3],"index":1},
    // Burpees
    {"name":"Burpees","group":["bröst","magmuskler-raka","lår"],"muscles":["f8","b5","f14","f15","f16","f17","f18"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/728","rep":"10","ID":"Burpees","rank":[2,3,1,1,1,1,1],"index":2},
    // Situps
    {"name":"Situps","group":["magmuskler-sida","magmuskler-raka","höftböjarmuskel"],"muscles":["f9","f10","f11","f12","f13","f14","b13"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/164","rep":"15","ID":"Situps","rank":[3,3,3,3,3,2,2],"index":3},
    // Crunches
    {"name":"Crunches","group":["magmuskler-sida","magmuskler-raka"],"muscles":["f9","f10","f11","f12","f13","f14"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/126","rep":"15","ID":"Crunches","rank":[3,3,3,3,3,2],"index":4},
    // Vadpress
    {"name":"Vadpress","group":["vader"],"muscles":["f21","f22","b21"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/574","rep":"20","ID":"Vadpress","rank":[3,3,3],"index":5},
    // Squats
    {"name":"Squats","group":["rumpa"],"muscles":["f14","b13","b14","f15","f16","f17"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/557","rep":"20","ID":"Squats","rank":[2,2,3,2,2,2],"index":6},
    // Chins med pronerat grepp
    {"name":"Chins med pronerat grepp","group":["biceps","övre-rygg"],"muscles":["f5","b9","b8"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/189","rep":"10","ID":"Chins-med-pronerat-grepp","rank":[3,3,2],"index":7},
    // Kissande hunden med armsträck
    {"name":"Kissande hunden med armsträck","group":["rumpa","nedre-rygg","axlar"],"muscles":["b14","b11","b4","f4"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/583","rep":"20","ID":"Kissande-hunden-med-armsträck","rank":[3,3,1,1],"index":8},
    // Utfallssteg
    {"name":"Utfallssteg","group":["lår","rumpa"],"muscles":["f15","f16","b14"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/387","rep":"20","ID":"Utfallssteg","rank":[3,3,3],"index":9},
    // Höftlyft
    {"name":"Höftlyft","group":["lår","rumpa"],"muscles":["b14","b15","b16","b17"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/322","rep":"20","ID":"Höftlyft","rank":[3,3,2,2],"index":10},
    // Vindrutetorkaren
    {"name":"Vindrutetorkaren","group":["magmuskler-sneda","höftböjarmuskeln"],"muscles":["f9","f14","b13"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/158","rep":"15","ID":"Vindrutetorkaren","rank":[3,2,2],"index":11},
    // Plankan
    {"name":"Plankan","group":["magmuskler-sneda","magmuskler-raka","höftböjarmuskeln"],"muscles":["f10","f11","f12","f13","f9","f14","f13"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/68","rep":"90 sek","ID":"Plankan","rank":[3,3,3,3,2,2,2],"index":12},
    // Kolmasken
    {"name":"Kolmasken","group":["triceps","bröst","axlar"],"muscles":["b5","f8","f4","b4"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/107","rep":"15","ID":"Kolmasken","rank":[3,3,2,2],"index":13},
    // Sissy Squats
    {"name":"Sissy Squats","group":["lår","magmuskler-raka"],"muscles":["f15","f16","f18","f10","f11","f12","f13"],"url":"http://www.styrkeprogrammet.se/ovningsarkiv/672","rep":"10","ID":"Sissy-Squats","rank":[3,3,3,3,3,3,2],"index":14},
  ]

// Loopar igenom kategori-listan och placerar ut dem.
category.forEach(function(a){
  let ID = (typeof a.ID === 'undefined'? a.title.toLowerCase(): a.ID);
  document.getElementById(a.parentID).innerHTML += `<li class="list-group-item"><a data-toggle="collapse" data-parent="#${a.parentID}" href="#list-${ID}" role="button" class="custom-header" aria-expanded="true">${a.title}</a><ul id="list-${ID}" class="collapse"></ul></li>`;
})

// Loopar igenom övningarna och placerar ut dem i sina kategorier på hemsidan.
exercises.forEach(function(a){
  
  let j = {
    "m" : JSON.stringify(a["muscles"]),
    "r" : JSON.stringify(a["rank"]),
    "i" : JSON.stringify(a["index"])
  }
  
  a["group"].forEach(function(b){
    document.getElementById('list-'+b).innerHTML += `<li class="list-group-item d-flex justify-content-between align-items-center" onmouseover='highlight(${j.m},${j.r})' onmouseleave='unhighlight(${j.m},${j.r})' onmouseup='select(${j.i})'>${a["name"]}</li>`
  })
})

// onmouseenter
function highlight (m,r) {  
  m.forEach(function(v,i){
    document.documentElement.style.setProperty( `--${v}`, col[pr[p.indexOf(v)]+r[i]] )
  });
}

// onmouseleave
function unhighlight(m,r) {
  m.forEach(function(v,i){
    document.documentElement.style.setProperty(`--${v}`, col[pr[p.indexOf(v)]]);
    /*
    console.log(v);
    console.log(p.indexOf(v));
    console.log(col[pr[p.indexOf(v)]]);
    //*/
  })
}

// onclick
function select(index) {
  let e = exercises[index];
  let m = e["muscles"],
      r = e["rank"];

  m.forEach(function(v,i){
    // Add the point.
    pr[p.indexOf(v)] += r[i];
    // Render the muscle colour.
    document.documentElement.style.setProperty( `--${v}`, col[pr[p.indexOf(v)]] );
  });
  console.log(pr)
  // Render
  highlight(m,r);
  // Add
  add(e);
}

// Lägg till i tabellistan
function add(ex) {
  console.log(ex)
  let e = ex;
  let myID = document.getElementById(e["ID"]);
  let am = `1x${e["rep"]}`;
  
  console.log( "Amount:", myID );
  console.log( "Exists:", myID !== null );
  
  if(myID !== null) {
    var elem = myID.children[1],
        rmatch = /(\D*)(\d+)(\D+)(\d+)(\D*)/.exec(elem.textContent);
    // Patterns matches: Foo*|20+|x+|50+|bar*
    // * = Matches ZERO or more
    // + = Matches ONE or more
    
    console.log("regex:", rmatch );
    
    rmatch.shift();
    
    rmatch[1] =
      ~~rmatch[1] + 1; // ~~"10" // 1) not not converts "sets" String to a Number. 2) Add 1
    
    console.log("regex2:", rmatch );
    
    elem.textContent = rmatch.join("");
    
  } else {
  
  et.innerHTML +=
`<tr id=${e["ID"]}>
<td>${e["name"]}</td>
<td>${am}</td>
<td><abbr title="Knappen länkar dig till ${e['url']}"><a target="_blank" href="${e['url']}"><i class="fas fa-external-link-alt url"></i></a></abbr></td>
<td>
  <i class="fas fa-minus plusMinus" onclick="subtract(event,${e["index"]})"></i>
  <i class="fas fa-times delete" onclick="remove(event,${e["index"]})"></i>
</td>
</tr>`
  }
}
// Subtraherar sets i övningar.
function subtract(e,index) {
  var elem = e.target.parentElement.parentElement.children[1],
      rmatch = /(\D*)(\d+)(\D+)(\d+)(\D*)/.exec(elem.textContent),
      ex = exercises[index],
      m = ex["muscles"],
      r = ex["rank"];
  
  rmatch.shift();
  
  rmatch[1] =
    ~~rmatch[1] - 1; // ~~"10" // 1) not not converts "sets" String to a Number. 2) Subtract 1
  
  console.log("regex:",rmatch)
  
  if ( rmatch[1] === 0 ) {
    // Tar bort övningen om den har 0 sets
    elem.parentElement.parentElement.removeChild(elem.parentElement);
  }
  
  elem.textContent = rmatch.join("");
  
  
  m.forEach(function(v,i){
    // Add the point.
    pr[p.indexOf(v)] -= r[i];
    // Render the muscle colour.
    document.documentElement.style.setProperty( `--${v}`, col[pr[p.indexOf(v)]] );
  });
}
// Tar bort övningen från tabellen
function remove(e,index) {
  var elem = e.target.parentElement.parentElement.children[1],
      rmatch = /(\D*)(\d+)(\D+)(\d+)(\D*)/.exec(elem.textContent),
      ex = exercises[index],
      m = ex["muscles"],
      r = ex["rank"];
  
  rmatch.shift();
  
  // Repetera antal sets och tar bort färg
    m.forEach(function(v,j){
      // Nollställer points.
      pr[p.indexOf(v)] -= r[j] * rmatch[1];
      // Render the muscle colour.
      document.documentElement.style.setProperty( `--${v}`, col[pr[p.indexOf(v)]] );
    });
  
  // Tar bort elementet
  elem.parentElement.parentElement.removeChild(elem.parentElement);
}